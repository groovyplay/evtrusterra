# Contains the sequential, three-layer logic: Rules, ML Simulation, and LLM Simulation.

import json
from src.models import VehicleInput, PredictionOutput

# --- Configuration ---
INITIAL_RV_BASE = 35000  # Base Residual Value for simulation
RUL_MAX_CAP = 120        # Absolute maximum RUL in months (10 years)

# --- Layer 1: Rules Engine Simulation ---
def _apply_rules(input_data: VehicleInput) -> dict:
    """
    
    This function simulates Layer 1: Rules Engine. It calculates hard caps and baselines.
    """
    
    # 1. Calculate max_rul_cap (Hard Constraint)
    # High mileage and high fast_charge_ratio impose a hard cap on RUL
    mileage_penalty = input_data.mileage_km / 100000.0  # Scale penalty by 100,000 km
    charge_penalty = input_data.fast_charge_ratio * 30  # Max 30 months penalty
    
    # Max RUL is reduced based on penalties, never below 12 months.
    max_rul_cap = RUL_MAX_CAP - (mileage_penalty * 6) - charge_penalty
    max_rul_cap = max(12, int(max_rul_cap)) 

    # 2. Calculate baseline_rv (RV Baseline)
    # Simple rule: RV starts high and is reduced by age and mileage.
    baseline_rv = INITIAL_RV_BASE * (1 - (input_data.age_years * 0.05))
    baseline_rv -= (input_data.mileage_km / 1000.0) * 0.1  # $0.1 per 1000 km
    baseline_rv = int(max(1000, baseline_rv))

    # Package output with augmented features
    augmented_features = input_data.model_dump()
    augmented_features['max_rul_cap'] = max_rul_cap
    augmented_features['baseline_rv'] = baseline_rv
    
    return augmented_features

# --- Layer 2: Core ML Models Simulation ---
def _predict_ml(features: dict) -> tuple[int, int]:
    """
    Simulates the two LightGBM models for RUL and RV prediction.
    
    This function simulates Layer 2: Core ML Models.
    Crucially, RV prediction uses RUL as an input feature.
    """
    
    # --- RUL Prediction (Simulated Model f_RUL) ---
    # RUL is primarily driven by SOH, constrained by the Rules Engine cap.
    predicted_rul = (features['current_soh'] * 100.0) + (features['age_years'] * -2)
    predicted_rul = int(min(features['max_rul_cap'], max(6, predicted_rul))) 

    # --- RV Prediction (Simulated Model f_RV) ---
    # RV is a function of baseline_rv, RUL, and other features
    rv_adjustment = (
        (features['baseline_rv'] * 0.8) +             # 80% weight on baseline
        (predicted_rul * 100) -                      # $100 per predicted RUL month
        (features['fast_charge_ratio'] * 2000)       # $2000 max penalty for fast charge
    )
    predicted_rv = int(max(5000, rv_adjustment))

    return predicted_rul, predicted_rv

# --- Layer 3: Explainability and Synthesis (LLM Simulation) ---
def _synthesize_explanation(input_data: VehicleInput, predicted_rul: int, predicted_rv: int) -> str:
    """
    Simulates a Small, Self-Hosted LLM that synthesizes an explanation 
    from predictions and feature drivers (simulated SHAP values).
    
    This function simulates Layer 3: LLM Synthesis.
    """
    
    # 1. Identify Top Drivers (Simulated SHAP/XAI)
    drivers = []
    
    if input_data.fast_charge_ratio > 0.3:
        drivers.append("a high ratio of DC fast charging events")
    if input_data.mileage_km > 80000:
        drivers.append("the vehicle's relatively high mileage")
    if input_data.current_soh < 0.75:
        drivers.append("the current State of Health (SOH) of the battery")
        
    drivers_list = ", ".join(drivers)
    
    # 2. LLM Synthesis (Template-based for simplicity)
    if drivers_list:
        explanation = (
            f"The predicted Remaining Useful Life (RUL) of **{predicted_rul} months** and "
            f"Residual Value (RV) of **{predicted_rv:,.0f}** are primarily driven by {drivers_list}. "
            "Our model scientifically links these factors, especially battery SOH and charging habits, "
            "to market value, providing a transparent valuation."
        )
    else:
        explanation = (
            f"The predicted RUL of **{predicted_rul} months** and RV of **${predicted_rv:,.0f}** "
            "are consistent with a well-maintained vehicle showing no unusual degradation factors. "
            "The valuation reflects the vehicle's age and general market condition."
        )

    return explanation

# --- Main Orchestration Function ---
def run_prediction_pipeline(input_data: VehicleInput) -> PredictionOutput:
    """
    The main orchestration function Hybrid Prediction Pipeline.
    
    1. Layer 1: Apply rules (hard caps/baselines).
    2. Layer 2: Core ML prediction (RUL & RV).
    3. Layer 3: LLM synthesis (Explanation).
    """
    
    # Layer 1: Rules Engine
    augmented_features = _apply_rules(input_data)
    
    # Layer 2: Core ML Prediction (simulated)
    predicted_rul, predicted_rv = _predict_ml(augmented_features)
    
    # Layer 3: LLM Synthesis (simulated)
    explanation = _synthesize_explanation(input_data, predicted_rul, predicted_rv)
    
    # Final Output
    return PredictionOutput(
        predicted_rul_months=predicted_rul,
        predicted_rv_usd=predicted_rv,
        explanation_text=explanation
    )
