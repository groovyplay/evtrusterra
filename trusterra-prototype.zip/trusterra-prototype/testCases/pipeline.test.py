
def test_rul_capping_by_rules_engine():
    """
    Should cap the predicted RUL at the value determined by the rules engine
    when the ML prediction is higher.
    """
    # Arrange: Create input where ML prediction would be high, but rules impose a lower cap.
    # - High SOH (1.0) and low age (1) -> ML RUL would be ~98 months.
    # - High mileage (150k km) and high fast charge ratio (0.8) -> Rules will impose a cap.
    #   max_rul_cap = 120 - (150000/100000 * 6) - (0.8 * 30) = 120 - 9 - 24 = 87
    input_data = VehicleInput(
        vehicle_id="test-rul-cap",
        mileage_km=150000,
        current_soh=1.0,
        fast_charge_ratio=0.8,
        avg_temp_c=25,
        age_years=1.0
    )
    
    # Act: Run the full pipeline
    result = run_prediction_pipeline(input_data)
    
    # Assert: The final RUL should be the capped value (87), not the higher ML prediction (~98).
    assert result.predicted_rul_months == 87
    assert "high ratio of DC fast charging events" in result.explanation_text
    assert "relatively high mileage" in result.explanation_text


def test_pipeline_enforces_minimum_rv():
    """
    Should enforce the minimum predicted RV of 5000 when calculations
    result in a lower value.
    """
    # This input is designed to produce a very low calculated RV:
    # - High age and mileage to reduce baseline_rv to its minimum (1000).
    # - High fast charge ratio for a large penalty.
    # - Low SOH to result in a low RUL, providing minimal positive adjustment.
    low_value_input = VehicleInput(
        vehicle_id="test-low-rv",
        mileage_km=250000,
        current_soh=0.6,
        fast_charge_ratio=1.0,
        avg_temp_c=35,
        age_years=20
    )

    # Run the full pipeline
    result = run_prediction_pipeline(low_value_input)

    # Assert that the final RV is capped at the floor of 5000, not the calculated value
    assert result.predicted_rv_usd == 5000


def test_pipeline_with_high_wear_vehicle():
    """
    Should correctly calculate a low RUL and RV for a vehicle with 
    high mileage, high fast charge ratio, and low SOH.
    """
    # Arrange: Create input for a vehicle with poor health indicators
    high_wear_input = VehicleInput(
        vehicle_id="test-high-wear",
        mileage_km=150000,
        current_soh=0.65,
        fast_charge_ratio=0.8,
        avg_temp_c=35,
        age_years=5
    )

    # Act: Run the full prediction pipeline
    result = run_prediction_pipeline(high_wear_input)

    # Assert: Check for low RUL, low RV, and a corresponding explanation
    # --- Manual Calculation for Verification ---
    # Layer 1: Rules
    # mileage_penalty = 150000 / 100000.0 = 1.5
    # charge_penalty = 0.8 * 30 = 24
    # max_rul_cap = 120 - (1.5 * 6) - 24 = 120 - 9 - 24 = 87
    # baseline_rv = 35000 * (1 - 5 * 0.05) - (150000 / 1000) * 0.1 = 35000 * 0.75 - 15 = 26250 - 15 = 26235
    # Layer 2: ML
    # rul_pre_cap = (0.65 * 100) + (5 * -2) = 65 - 10 = 55
    # predicted_rul = min(87, max(6, 55)) = 55
    # rv_adjustment = (26235 * 0.8) + (55 * 100) - (0.8 * 2000) = 20988 + 5500 - 1600 = 24888
    # predicted_rv = max(5000, 24888) = 24888
    
    assert result.predicted_rul_months == 55
    assert result.predicted_rv_usd == 24888
    
    # Assert that the explanation identifies all the negative drivers
    assert "high ratio of DC fast charging events" in result.explanation_text
    assert "relatively high mileage" in result.explanation_text
    assert "current State of Health (SOH) of the battery" in result.explanation_text
    assert f"RUL of **{result.predicted_rul_months} months**" in result.explanation_text
    assert f"RV of **${result.predicted_rv_usd:,.0f}**" in result.explanation_text


def test_run_prediction_pipeline_new_vehicle():
    """
    Should produce a high RUL and high RV for a new vehicle with perfect stats.
    """
    # A brand new vehicle with 0 mileage, perfect SOH, and no fast charging
    input_data = VehicleInput(
        vehicle_id="new-car-001",
        mileage_km=0.0,
        current_soh=1.0,
        fast_charge_ratio=0.0,
        avg_temp_c=25.0,
        age_years=0.0
    )

    # --- Manually calculate expected values based on pipeline logic ---
    # Layer 1: Rules
    # max_rul_cap = 120 - (0/100k * 6) - (0*30) = 120
    # baseline_rv = 35000 * (1 - 0) - (0/1k * 0.1) = 35000
    expected_max_rul_cap = 120
    expected_baseline_rv = 35000

    # Layer 2: ML
    # predicted_rul = (1.0 * 100) + (0 * -2) = 100
    # predicted_rul = min(120, max(6, 100)) = 100
    expected_rul = 100
    # rv_adjustment = (35000 * 0.8) + (100 * 100) - (0 * 2000) = 28000 + 10000 = 38000
    # predicted_rv = max(5000, 38000) = 38000
    expected_rv = 38000

    # Layer 3: Explanation (no negative drivers)
    expected_explanation = (
        f"The predicted RUL of **{expected_rul} months** and RV of **${expected_rv:,.0f}** "
        "are consistent with a well-maintained vehicle showing no unusual degradation factors. "
        "The valuation reflects the vehicle's age and general market condition."
    )

    # --- Run pipeline ---
    result = run_prediction_pipeline(input_data)

    # --- Assertions ---
    assert result.predicted_rul_months == expected_rul
    assert result.predicted_rv_usd == expected_rv
    assert result.explanation_text == expected_explanation
    assert isinstance(result, PredictionOutput)


def test_pipeline_explanation_all_drivers():
    """
    Should generate an explanation listing all three drivers for a vehicle
    with high mileage, high fast charging, and low SOH.
    """
    # Arrange: Create input that triggers all three explanation conditions
    input_data = VehicleInput(
        vehicle_id="test-all-drivers",
        mileage_km=95000,          # > 80000
        current_soh=0.70,          # < 0.75
        fast_charge_ratio=0.5,     # > 0.3
        avg_temp_c=25,
        age_years=4
    )

    # Act: Run the full prediction pipeline
    result = run_prediction_pipeline(input_data)

    # Assert: Check that all three drivers are mentioned in the explanation text
    explanation = result.explanation_text
    assert "a high ratio of DC fast charging events" in explanation
    assert "the vehicle's relatively high mileage" in explanation
    assert "the current State of Health (SOH) of the battery" in explanation

    # Also verify the predicted values are embedded correctly
    # Manually calculated expected values: RUL=62, RV=22792
    assert f"**{result.predicted_rul_months} months**" in explanation
    assert f"**${result.predicted_rv_usd:,.0f}**" in explanation


def test_synthesize_explanation_well_maintained():
    """
    Tests that the 'well-maintained' explanation is generated when no negative
    driving factors are present in the input data.
    """
    # Arrange: Create input data that does NOT trigger any negative driver conditions
    # (fast_charge_ratio <= 0.3, mileage_km <= 80000, current_soh >= 0.75)
    good_input = VehicleInput(
        vehicle_id="test-good-car",
        mileage_km=50000,
        current_soh=0.95,
        fast_charge_ratio=0.1,
        avg_temp_c=25,
        age_years=2
    )
    predicted_rul = 90
    predicted_rv = 28000

    # Act: Generate the explanation
    explanation = _synthesize_explanation(good_input, predicted_rul, predicted_rv)

    # Assert: Check for the specific 'well-maintained' template string
    expected_text = (
        f"The predicted RUL of **{predicted_rul} months** and RV of **${predicted_rv:,.0f}** "
        "are consistent with a well-maintained vehicle showing no unusual degradation factors. "
        "The valuation reflects the vehicle's age and general market condition."
    )
    assert explanation == expected_text
    # Also assert that none of the negative driver phrases are present
    assert "high ratio" not in explanation
    assert "high mileage" not in explanation
    assert "State of Health" not in explanation


def test_apply_rules_enforces_minimum_rul_cap():
    """
    Should enforce the minimum rule-based RUL cap of 12 months for a vehicle
    with extremely high mileage and fast charging that would otherwise result in a lower cap.
    """
    # Arrange: Create input with extreme values that would push the cap below 12
    # RUL_MAX_CAP (120) - (mileage_penalty * 6) - charge_penalty
    # mileage_penalty = 2,000,000 / 100,000 = 20 -> 20 * 6 = 120 penalty
    # charge_penalty = 1.0 * 30 = 30 penalty
    # Calculated cap = 120 - 120 - 30 = -30, which should be floored at 12.
    input_data = VehicleInput(
        vehicle_id="test-extreme-penalty",
        mileage_km=2000000,
        current_soh=0.8,
        fast_charge_ratio=1.0,
        avg_temp_c=25,
        age_years=8
    )

    # Act: Run the rules engine layer
    augmented_features = _apply_rules(input_data)

    # Assert: The max_rul_cap should be capped at the minimum of 12
    assert augmented_features['max_rul_cap'] == 12


def test_rul_minimum_floor_with_low_soh():
    """
    Should enforce the minimum predicted RUL of 6 months when SOH is extremely low.
    The _predict_ml function has a `max(6, ...)` clause to prevent RUL from dropping below 6.
    """
    # Arrange: Create input with extremely low SOH that would otherwise result in a RUL < 6
    low_soh_input = VehicleInput(
        vehicle_id="test-min-rul",
        mileage_km=10000,
        current_soh=0.05,  # This would calculate to 5 months before the floor is applied
        fast_charge_ratio=0.0,
        avg_temp_c=25,
        age_years=0
    )

    # Act: Run the full pipeline
    result = run_prediction_pipeline(low_soh_input)

    # Assert: The final predicted RUL should be capped at the minimum of 6 months
    assert result.predicted_rul_months == 6, "The pipeline should enforce a minimum RUL of 6 months."


def test_apply_rules_new_vehicle_high_baseline_rv():
    """
    Should correctly calculate a high baseline RV for a new vehicle with zero age and mileage.
    """
    # Arrange: Create a new vehicle with zero age and mileage
    new_vehicle_input = VehicleInput(
        vehicle_id="test-new-car",
        mileage_km=0,
        current_soh=1.0,
        fast_charge_ratio=0.0,
        avg_temp_c=25.0,
        age_years=0
    )

    # Act: Apply the rules engine
    augmented_features = _apply_rules(new_vehicle_input)

    # Assert: The baseline RV should be the initial base value, as there are no deductions for age or mileage.
    assert 'baseline_rv' in augmented_features
    assert augmented_features['baseline_rv'] == INITIAL_RV_BASE


def test_apply_rules_enforces_minimum_baseline_rv():
    """
    Should enforce the minimum baseline RV of 1000 for a very old and high-mileage vehicle.
    """
    # Arrange: Create input for a vehicle that would otherwise have a very low or negative RV
    # A 20-year-old car would have its value reduced to zero by the age factor alone.
    input_data = VehicleInput(
        vehicle_id="test-old-car",
        mileage_km=500000,
        current_soh=0.5,
        fast_charge_ratio=0.5,
        avg_temp_c=25,
        age_years=20  # This will make the age multiplier negative or zero
    )

    # Act: Apply the rules engine
    augmented_features = _apply_rules(input_data)

    # Assert: The baseline_rv should be capped at the minimum of 1000
    # Calculation check:
    # baseline_rv = 35000 * (1 - (20 * 0.05)) = 35000 * 0 = 0
    # baseline_rv -= (500000 / 1000.0) * 0.1 = 0 - 50 = -50
    # int(max(1000, -50)) should be 1000
    assert augmented_features['baseline_rv'] == 1000
