# To run this file: uvicorn main:app --reload

from fastapi import FastAPI
from src.models import VehicleInput, PredictionOutput
from src.pipeline import run_prediction_pipeline
import os
import json

# Initialize FastAPI application
app = FastAPI(
    title="Hybrid Prediction API",
    version="v1.0.0",
    description="API for EV Remaining Useful Life (RUL) and Residual Value (RV) Prediction."
)

@app.get("/")
async def root():
    """Simple health check endpoint."""
    return {"message": "TrusTerra Prediction API is running. Go to /docs for API documentation."}


@app.post("/v1/predict", response_model=PredictionOutput, status_code=200)
async def predict(input_data: VehicleInput):
    """
    Endpoint to receive structured vehicle data and return RUL, RV, and 
    a synthesized explanation via the three-layer hybrid pipeline.
    
    The request body must conform to the VehicleInput Pydantic schema.
    """
    try:
        # Pass the validated input data to the main prediction pipeline
        prediction_result = run_prediction_pipeline(input_data)
        
        # In a production environment, you would log the input, output, and model version here
        
        return prediction_result
    
    except Exception as e:
        # Simple error handling; in production, use logging and clearer HTTPException
        return {"error": f"An error occurred during prediction: {str(e)}"}

# --- Utility for CLI/Local Testing (Optional but helpful) ---
def run_cli_test():
    """Reads sample_input.json and runs a prediction test via CLI."""
    print("\n--- Running CLI Test with sample_input.json ---")
    try:
        # Resolve path safely for local execution
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sample_path = os.path.join(current_dir, "sample_input.json")
        
        with open(sample_path, 'r') as f:
            sample_data = json.load(f)
            
        # Manually validate and create the input model instance
        input_model = VehicleInput(**sample_data)
        
        # Run the pipeline
        result = run_prediction_pipeline(input_model)
        
        print("\nInput Data:")
        print(json.dumps(input_model.model_dump(), indent=2))
        
        print("\nPrediction Output:")
        print(json.dumps(result.model_dump(), indent=2))
        print(f"\nModel Version: {result.model_version}")

    except FileNotFoundError:
        print("Error: sample_input.json not found. Ensure it is in the same directory.")
    except Exception as e:
        print(f"Error during CLI test: {e}")

if __name__ == "__main__":
    # If run directly via `python main.py`, execute the CLI test
    run_cli_test()
