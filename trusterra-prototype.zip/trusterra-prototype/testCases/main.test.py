
from fastapi.testclient import TestClient
from unittest.mock import patch
from .main import app
from src.models import PredictionOutput

client = TestClient(app)

def test_root_endpoint_returns_200_and_welcome_message():
    """
    Should return a 200 status and a welcome message for a GET request to the root endpoint.
    """
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "TrusTerra Prediction API is running. Go to /docs for API documentation."}

def test_predict_success_valid_input():
    """
    Should return a 200 status and a valid prediction output for a POST request
    with a complete and valid VehicleInput payload.
    """
    # 1. Define valid input data
    valid_payload = {
        "vehicle_id": "test-vin-001",
        "mileage_km": 50000,
        "current_soh": 0.95,
        "fast_charge_ratio": 0.3,
        "avg_temp_c": 25.5,
        "age_years": 2.5
    }

    # 2. Define the expected output from the mocked pipeline
    mock_prediction = PredictionOutput(
        predicted_rul_months=48,
        predicted_rv_usd=25000,
        explanation_text="This is a mock explanation.",
        model_version="v1.0.0-hybrid-sim"
    )

    # 3. Mock the pipeline function to isolate the endpoint logic
    with patch('main.run_prediction_pipeline', return_value=mock_prediction) as mock_pipeline:
        # 4. Make the request to the endpoint
        response = client.post("/v1/predict", json=valid_payload)

        # 5. Assert the response and behavior
        assert response.status_code == 200
        mock_pipeline.assert_called_once()
        
        # 6. Validate the response body against the PredictionOutput schema
        response_data = response.json()
        assert response_data["predicted_rul_months"] == mock_prediction.predicted_rul_months
        assert response_data["predicted_rv_usd"] == mock_prediction.predicted_rv_usd
        assert "explanation_text" in response_data
        assert response_data["model_version"] == mock_prediction.model_version

def test_predict_invalid_data_type():
    """
    Tests that the /v1/predict endpoint returns a 422 Unprocessable Entity error
    when a field in the request body has an incorrect data type.
    """
    # Arrange: Payload with 'mileage_km' as a string instead of a float
    invalid_payload = {
        "vehicle_id": "test-vin-invalid-type",
        "mileage_km": "fifty-thousand",  # Incorrect data type
        "current_soh": 0.95,
        "fast_charge_ratio": 0.5,
        "avg_temp_c": 25.0,
        "age_years": 2.0
    }
    
    # Act: Make a POST request with the invalid payload
    response = client.post("/v1/predict", json=invalid_payload)
    
    # Assert: The status code should be 422 for a validation error
    assert response.status_code == 422
    # Optionally, assert that the error message points to the correct field
    response_json = response.json()
    assert response_json["detail"][0]["loc"] == ["body", "mileage_km"]
    assert "Input should be a valid number" in response_json["detail"][0]["msg"]

def test_predict_pipeline_exception(mocker):
    """
    Should return a JSON object with an error message if the internal prediction pipeline raises an exception.
    """
    # Arrange: Mock the pipeline function to raise a generic exception
    mocker.patch(
        'main.run_prediction_pipeline', 
        side_effect=Exception("Internal simulation failed")
    )
    
    # A valid input payload is still required to pass Pydantic validation
    valid_input_data = {
        "vehicle_id": "error-test-vehicle",
        "mileage_km": 60000,
        "current_soh": 0.88,
        "fast_charge_ratio": 0.6,
        "avg_temp_c": 28.0,
        "age_years": 3.0
    }

    # Act: Make a POST request to the endpoint
    response = client.post("/v1/predict", json=valid_input_data)
    response_data = response.json()

    # Assert: Check for the 200 status and the specific error structure in the body
    assert response.status_code == 200
    assert "error" in response_data
    assert response_data["error"] == "An error occurred during prediction: Internal simulation failed"

def test_run_cli_test_file_not_found(capsys, monkeypatch):
    """
    Test that run_cli_test prints a FileNotFoundError message if sample_input.json is missing.
    """
    # Mock os.path.join to return a path that we know doesn't exist
    # and then mock open to ensure it raises FileNotFoundError.
    # A simpler way is to just mock the 'open' call within the function's scope.
    def mock_open(*args, **kwargs):
        raise FileNotFoundError

    monkeypatch.setattr("builtins.open", mock_open)
    
    # Run the function that is expected to fail
    run_cli_test()
    
    # Capture the printed output
    captured = capsys.readouterr()
    
    # Assert that the correct error message is in the stdout
    assert "--- Running CLI Test with sample_input.json ---" in captured.out
    assert "Error: sample_input.json not found. Ensure it is in the same directory." in captured.out
