# src/models.py
# Defines strict Pydantic schemas for data validation and clear input/output structure.

from pydantic import BaseModel, Field

# --- Input Model ---
class VehicleInput(BaseModel):
    """
    Schema for structured battery and vehicle input data.
    These fields represent engineered features derived from raw IoT logs.
    """
    vehicle_id: str = Field(..., description="Unique identifier for the vehicle.")
    mileage_km: float = Field(..., ge=0, description="Current total mileage in kilometers.")
    current_soh: float = Field(..., ge=0.0, le=1.0, description="Current State of Health (0.0 to 1.0).")
    fast_charge_ratio: float = Field(..., ge=0.0, le=1.0, description="Proportion of charging energy from DC fast chargers.")
    avg_temp_c: float = Field(..., ge=-50, le=100, description="Average battery operating temperature.")
    age_years: float = Field(..., ge=0, description="Age of the vehicle in years.")


# --- Output Model ---
class PredictionOutput(BaseModel):
    """
    Schema for the final output of the hybrid prediction pipeline.
    """
    predicted_rul_months: int = Field(..., ge=0, description="Predicted Remaining Useful Life in months.")
    predicted_rv_usd: int = Field(..., ge=0, description="Predicted Residual Value in USD.")
    explanation_text: str = Field(..., description="LLM-synthesized non-technical justification for the prediction.")
    model_version: str = Field("v1.0.0-hybrid-sim", description="Version of the deployed prediction model/pipeline.")